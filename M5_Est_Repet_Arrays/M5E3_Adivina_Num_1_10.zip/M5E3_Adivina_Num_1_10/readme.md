(M5) Ejercicio 3. Adivina el número entre 0 y 10.

Esta línea de código:

Math.ceil((Math.random() * 10));
Devuelve un número entre el 0 y el 10 de forma aleatoria.

El ejercicio consiste en que el usuario/a debe adivinar el número escogido aleatoriamente por el programa.

El programa, pide números al usuario/a hasta que éste acierte el número aleatorio generado por el programa.

Una vez que el usuario/a ha adivinado el número, se mostrará por pantalla el siguiente mensaje: "Enhorabuena, el número era X".

## html
 input numberUser
 button
 p id result "Enhorabuena, el número era X"
