(M5) Ejercicio EXTRA 1. Realiza el programa de frío-frío, caliente-caliente
Realizar un juego para adivinar un número aleatorio N, entre 1 y 500.

Si la distancia entre el número a adivinar y el del usuario/a es de 50 o además, el programa deberá decir:

"Frío, frío: tu número es mayor " o "Frío, frío: tu número es más pequeño "



Si la distancia entre el número a adivinar y el del usuario/a está entre 15 y 50, el programa deberá decir:

"Tebio, Tebio: el tu número es mayor " o "Tebio, Tebio: tu número es más pequeño " 



Y si la distancia entre el número a adivinar y el del usuario/a y si la distancia es menor a 15, el programa deberá decir:

"Caliente, caliente: tu número es más grande " o "Caliente, caliente: tu número es más pequeño "

El proceso termina cuando el usuario/a acierta.

## html
button to start

## js
function
prompt bucle
if 6
imprimir resultado de pista
si adivina imprimir resultado Felicidades!