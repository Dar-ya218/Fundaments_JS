(M5) Ejercicio 1. El usuario/a decide cuántas palabras quiere introducir.

Hacer un programa que pregunte al usuario/a por el número (número) de palabras que se quieren introducir en un array.

Una vez que el usuario/a responda, el programa deberá preguntar por tantas palabras como el número (número) de palabras que ha dicho el usuario/a que quería introducir.

Las palabras se irán guardando en el array y una vez han sido todas introducidas, se muestran por pantalla.

## html
input number
button
p con id

## js
funcion
variable number
bucle FOR con promt