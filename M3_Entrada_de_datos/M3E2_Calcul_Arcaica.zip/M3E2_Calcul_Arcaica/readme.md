crear 2 imput para pedir numeros
buttun
4 p para imprimir resultado