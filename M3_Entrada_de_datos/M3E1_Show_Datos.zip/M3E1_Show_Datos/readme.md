## html
input para nombre

## js
promt apellido
promt edad

mostrar consola los resultados de los 3
mostrar resultado por alert
imprimir resultaro pen HTML