(M3) Ejercicio 3. Promedio de 3 notas
El programa pide al usuario/a que introduzca 3 notas y el programa muestra la media de las 3 notas por pantalla.

## html
pedir 3 notas por input
buttun para ejecutar
p para imprimir resultado


## js
funcion
3 variables constantes y traducir al numeto
hacer la suma y sacar promedio
imprimir el resultado en html

