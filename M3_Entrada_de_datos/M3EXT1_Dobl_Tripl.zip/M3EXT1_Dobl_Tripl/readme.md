(M3) Ejercicio EXTRA 1. Calcula el doble y triple
Escribe un programa JavaScript que lee un número (número) y muestra por pantalla el doble y el triple de este número.

## html
pedir un numero input
button
p result doble
p result triple

## js
funcion
const number
const number
calcular doble
calculat triple
imprimir en html los dos resultados
