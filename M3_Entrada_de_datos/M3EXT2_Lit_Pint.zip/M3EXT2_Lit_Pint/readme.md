(M3) Ejercicio EXTRA 2. Litros de pintura necesarios.
Escribe un programa JavaScript que calcule los litros de pintura necesarios para pintar una pared rectangular.

Un litro de pintura cubre aproximadamente, 12 m² en una sola mano.

Crear una constante, Cobertura a Litros (recordar las convenciones de nombres) para guardar el dato de cobertura de la pintura (12 m²).

Deberás pedir al usuario/a:

El alto y ancho de la pared (multiplicando sabrás el área de la misma).
El número de manos a aplicar.
Muestra en pantalla los litros de pintura a utilizar.

## html
 input alto de pared
 input ancho de pared
 buttun
 p resultado en litros

## js
 crear :
 const de 1 litrro = 12m2
 const result = ancho * alto
 imprimir result en HTML


