function calculateLiter() {

    const oneLiter = 12
    console.log("oneliter" + oneLiter)
    const widthUser = Number(document.getElementById("widthWall").value);
    const heightUser = Number(document.getElementById("highWall").value); 
    const hands = Number(document.getElementById("times").value);

    const surfaceUser = widthUser * heightUser;
    const literUser = (surfaceUser / oneLiter) * hands;


    document.getElementById("result").innerHTML = `La pintura necesaria para pintar tu superficie de ${surfaceUser} es de ${literUser}`

}