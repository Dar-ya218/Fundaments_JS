(M7.1.) Exercici 6. Taula de multiplicar

L’usuari/ària introduirà un número (de l'1 al 10) per pantalla, i utilitzant un bucle, el programa li mostrarà la taula de multiplicar d’aquell número.

Exemple:

2 x 1 = 2
2 x 2 = 4
2 x 3 = 6

...

2 x 10 = 20



## html
* H1
* INPUT/prompt
* button
* p vacio

##  js
* const
** inputUserNum
**  function (input)
