(M7.2.) Ejercicio 5. Calcula si el número es primo o no.
El usuario/a introduce un número por teclado y el programa llama a un método que indique si el número es primo o no.

## html

input num
button
p id result


## js

funcion
