(M7.2.) Ejercicio 6. Pide número hasta que introduzca un número primo.
El usuario/a debe introducir números hasta que introduzca un número primero.

En el momento que el usuario/a introduzca un número primo, el programa debe sacar por pantalla el siguiente mensaje: "¡Exacto, el número "x" es primo!"

