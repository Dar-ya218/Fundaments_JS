(M7.2.) Ejercicio 8. Muestra la sucesión de Fibonacci.
El usuario/a introduce un número por teclado y el programa llama a un método que debe mostrar la sucesión de Fibonacci.

Ejemplo:

Si el usuario/a introduce el 10, el resultado debe ser:

0,1,1,2,3,5,8,13,21,34
