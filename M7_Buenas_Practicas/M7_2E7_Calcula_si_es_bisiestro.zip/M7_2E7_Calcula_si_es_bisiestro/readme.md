(M7.2.) Ejercicio 7. Calcula si el año es de traspaso.
El usuario/a introduce un año "a" por teclado
y el programa llama a un método que indique si el año es de traspaso o no.

## html

Input
button
id result

## js
 
 function
 const
 if