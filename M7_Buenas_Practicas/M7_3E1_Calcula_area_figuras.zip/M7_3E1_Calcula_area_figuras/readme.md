(M7.3.) Ejercicio 1. Calcula el área de figuras geométricas.
Realizar un programa con el siguiente menú en HTML:
 Cuadrado (costat * costat)
 Triangulo (base* altura/2)
 Rectangulo (base * altura)
 Circulo (Math.PL * radio **2)
Según la opción escogida deberá introducir unos datos u otros para que el programa muestre por pantalla
el área (el valor) del polígono escogido.

## html
h2: 
 Cuadrado (costat * costat)
 Triangulo (base* altura/2)
 Rectangulo (base * altura)
 Circulo (Math.PL * radio **2)

input text pedir figura
bottun
id result

## js
Function
const figuraUser
if(formula)
imprimir result
