function suma(){
    let largo = Number(document.getElementById("numUser").value)
    let sumaPar = 0
    for (let i=1; i< largo; i++){
      if (i%2 === 0) {
        sumaPar += i
      }
    }
 

    let sumResta = 0
    for (let i=1; i< largo; i++){
      if (i%2 !== 0) {
        sumResta += i
      }
    }
    
    document.getElementById("result").innerHTML= `La suma de los pares es ${sumaPar} y suma de impares es ${sumResta}`
}

