(M7.1.) Ejercicio 4. Indica si uno de los números es negativo
El usuario/a debe introducir dos números, el programa retornará "Uno de los dos números es negativo", sólo si uno de los dos números es negativo.

## html
input
input
button
p id result

## js
function
const numero1
const numero2
comprobar si numero es negarivo Math.sign()
if 
