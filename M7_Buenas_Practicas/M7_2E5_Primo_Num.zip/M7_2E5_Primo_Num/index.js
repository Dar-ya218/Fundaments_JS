function calculate(){
    const userNumber = Number(document.getElementById("userNum").value);

    for (let index = 2; index < userNumber; index++) {
        if (userNumber%index === 0 ) {
            let isPrime = false  
            //console.log (isPrime)
            document.getElementById("result").innerHTML= `El numero ${userNumber} no es primo`
            return 
        }
        else {isPrime = true}
    }
    //console.log (isPrime)
    document.getElementById("result").innerHTML= `El numero ${userNumber} es primo`
}
