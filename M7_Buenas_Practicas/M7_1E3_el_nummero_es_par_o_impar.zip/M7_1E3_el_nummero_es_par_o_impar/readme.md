(M7.1.) Ejercicio 3. ¿El número es par o impar?
El usuario/a debe introducir un número y el programa debe mostrar por pantalla si el número es par o impar.

## html 
imput numero
button
p id result

## js

funcion
const number
const even = number % 2 === 0
const odd = number %2 !== 0
if   even
imprimir " es par"
if odd
imprimir " es impar"
