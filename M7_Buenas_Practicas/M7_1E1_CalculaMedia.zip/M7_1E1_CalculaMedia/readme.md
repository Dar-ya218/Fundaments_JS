(M7.1.) Ejercicio 1. Calcula la media de tres notas e indica si has aprobado o suspendido

Crea un programa donde el usuario/a introduce tres notas y el programa calcule la media.

Si la media es inferior a 5 debe mostrar el siguiente mensaje por pantalla: "No has superado el curso. Tienes que recuperar".

Si la media está entre 5 y 7 debe mostrar: "¡Enhorabuena! Has aprobado, pero deberías seguir practicando".

Si la media es superior a 7 debe mostrar: "¡Enhorabuena! ¡Has superado el curso! ¡Pasa ya al siguiente nivel!"

## html
pedir 3 notas por input
buttun para ejecutar
p para imprimir resultado


## js
funcion
3 variables constantes y traducir al numeto
hacer la suma y sacar promedio
imprimir el resultado en html
if

